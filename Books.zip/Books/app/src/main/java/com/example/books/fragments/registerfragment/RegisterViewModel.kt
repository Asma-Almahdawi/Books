package com.example.books.fragments.registerfragment

import androidx.lifecycle.ViewModel

class RegisterViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}