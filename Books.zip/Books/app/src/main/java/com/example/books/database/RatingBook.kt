package com.example.books.database

data class RatingBook(
    
    val userRating :String = ""
    
    
) {
}