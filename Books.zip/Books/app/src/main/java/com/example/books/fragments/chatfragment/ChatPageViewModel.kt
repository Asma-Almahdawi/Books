package com.example.books.fragments.chatfragment

import androidx.lifecycle.ViewModel

class ChatPageViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}