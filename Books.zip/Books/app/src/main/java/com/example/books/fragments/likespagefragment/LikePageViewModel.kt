package com.example.books.fragments.likespagefragment

import androidx.lifecycle.ViewModel

class LikePageViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}