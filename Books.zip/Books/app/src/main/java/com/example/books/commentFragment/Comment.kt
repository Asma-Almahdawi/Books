package com.example.books.commentFragment

import java.security.acl.Owner

data class Comment(

    var commentText :String = "",

) {


}